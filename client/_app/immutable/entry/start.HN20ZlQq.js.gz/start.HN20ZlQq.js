import{l as o,a as r}from"../chunks/B5vJIVh4.js";export{o as load_css,r as start};
