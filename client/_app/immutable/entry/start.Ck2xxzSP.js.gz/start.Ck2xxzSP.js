import{l as o,a as r}from"../chunks/Dq0Mk-ag.js";export{o as load_css,r as start};
